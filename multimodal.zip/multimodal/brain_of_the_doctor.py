import base64
import os
# from groq import Groq
from dotenv import load_dotenv

# # Step 1: Setup Groq and API key
load_dotenv()
hf_token = os.getenv("HUGGINGFACE_TOKEN")

# Step 2: Convert image to base64-encoded string
image_path = 'x-ray.jpeg'
with open(image_path, 'rb') as image_file:
    encoded_image = base64.b64encode(image_file.read()).decode('utf-8')

# Step 3: Prepare query and model
query = (
    "Please carefully analyze this image and describe in detail what you observe. "
    "If the image contains a human face, identify any visible signs of skin conditions, injuries, or unusual features. "
    "If it's a medical image (like an X-ray, MRI, or rash), describe the likely condition shown. "
    "In all cases, provide possible explanations and recommended next steps or treatments if any issues are found."
)
from transformers import AutoTokenizer, AutoModelForCausalLM

tokenizer = AutoTokenizer.from_pretrained("meta-llama/Llama-4-Scout-17B-16E-Instruct", token=hf_token)
model = AutoModelForCausalLM.from_pretrained("meta-llama/Llama-4-Scout-17B-16E-Instruct", token=hf_token)

#model="llama-3.2-90b-vision-preview" #Deprecated

def analyze_image_with_query(query, model, encoded_image):
    client=model()  
    messages=[
        {
            "role": "user",
            "content": [
                {
                    "type": "text", 
                    "text": query
                },
                {
                    "type": "image_url",
                    "image_url": {
                        "url": f"data:image/jpeg;base64,{encoded_image}",
                    },
                },
            ],
        }]
    chat_completion=client.chat.completions.create(
        messages=messages,
        model=model
    )

    print(chat_completion.choices[0].message.content)

analyze_image_with_query(query, model,encoded_image)

# from transformers import AutoModelForImageClassification, AutoImageProcessor
# from transformers import BioGptTokenizer, BioGptForCausalLM
# from PIL import Image
# import torch

# # --- Load Chest X-ray Image ---
# image = Image.open("x-ray.jpeg").convert("RGB")

# # --- STEP 1: Medical Image Classification ---
# model_id = "yikuan8/chexpert-resnet50"
# processor = AutoImageProcessor.from_pretrained(model_id)
# model = AutoModelForImageClassification.from_pretrained(model_id)

# inputs = processor(images=image, return_tensors="pt")
# with torch.no_grad():
#     outputs = model(**inputs)
#     probs = torch.sigmoid(outputs.logits[0])  # For multilabel classification

# # Get top findings
# top_indices = torch.topk(probs, k=5).indices
# labels = [model.config.id2label[i.item()] for i in top_indices]
# finding_text = ", ".join(labels)
# print("🩺 Detected Findings:", finding_text)

# # --- STEP 2: Generate Report using BioGPT ---
# bio_model_id = "microsoft/biogpt"
# tokenizer = BioGptTokenizer.from_pretrained(bio_model_id)
# biogpt = BioGptForCausalLM.from_pretrained(bio_model_id)

# prompt = f"The chest X-ray shows the following findings: {finding_text}. Based on this, the medical report is as follows:\n"
# input_ids = tokenizer(prompt, return_tensors="pt").input_ids
# generated_ids = biogpt.generate(input_ids, max_length=300)
# report = tokenizer.decode(generated_ids[0], skip_special_tokens=True)

# print("\n📋 Generated Medical Report:\n", report)

