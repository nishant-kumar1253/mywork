import pandas as pd
from datasets import Dataset, DatasetDict
from transformers import (
    BioGptTokenizer,
    BioGptForCausalLM,
    Trainer,
    TrainingArguments,
    DataCollatorForLanguageModeling,
)

# Step 1: Load and clean CSV
df = pd.read_csv("diseasenew.csv", encoding="ISO-8859-1")
df.columns = df.columns.str.strip()  # Remove extra spaces in column names
df = df.dropna(subset=["Name","Explanation"])  # Ensure no missing data

# Step 2: Convert to Hugging Face Dataset
hf_dataset = Dataset.from_pandas(df)

# Step 3: Split dataset
train_testvalid = hf_dataset.train_test_split(test_size=0.1, seed=42)
test_valid = train_testvalid["test"].train_test_split(test_size=0.5, seed=42)

dataset = DatasetDict({
    "train": train_testvalid["train"],
    "valid": test_valid["train"],
    "test": test_valid["test"]
})

# Step 4: Load BioGPT model and tokenizer
tokenizer = BioGptTokenizer.from_pretrained("microsoft/biogpt")
model = BioGptForCausalLM.from_pretrained("microsoft/biogpt")

# Step 5: Add prompt and answer for training
def add_prompt(example):
    example["text"] = f"What is {example['Name']}? {example['Explanation']} {tokenizer.eos_token}"
    return example

dataset = dataset.map(add_prompt)

# Step 6: Tokenize the data
def tokenize(example):
    encoding = tokenizer(
        example["text"],
        truncation=True,
        padding="max_length",
        max_length=512
    )
    encoding["labels"] = encoding["input_ids"].copy()
    return encoding

tokenized_dataset = dataset.map(tokenize, batched=True)
tokenized_dataset.set_format(type="torch", columns=["input_ids", "attention_mask", "labels"])

# Step 7: Data collator
data_collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=False)

# Step 8: Training arguments (CPU friendly)
training_args = TrainingArguments(
    output_dir="./biogpt-finetuned",
    per_device_train_batch_size=1,          
    save_steps=1000,
    logging_steps=100,
    save_total_limit=1,
    logging_dir="./logs",
    report_to="none",                   
    evaluation_strategy="epoch"
)

# Step 9: Trainer
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_dataset["train"],
    eval_dataset=tokenized_dataset["valid"],
    data_collator=data_collator,
)

# Step 10: Train the model
trainer.train()

# Step 11: Save the model and tokenizer
trainer.save_model("./biogpt-finetuned")
tokenizer.save_pretrained("./biogpt-finetuned")
