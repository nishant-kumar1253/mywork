import streamlit as st
import torch
from transformers import set_seed, BioGptTokenizer, BioGptForCausalLM

st.title("🧠 BioGPT Medical Explanation Generator")

# Cache model/tokenizer loading to avoid reloading every time
@st.cache_resource
def load_model_tokenizer(model_dir):
    tokenizer = BioGptTokenizer.from_pretrained(model_dir)
    model = BioGptForCausalLM.from_pretrained(model_dir)
    model.eval()
    return tokenizer, model

model_dir = r"C:\Users\admin\Desktop\biogpt\biogpt-finetuned"
tokenizer, model = load_model_tokenizer(model_dir)

# Guide users to enter prompts in correct format
prompt = st.text_input(
    "Enter your query in the form 'What is <disease_name>?' (e.g., 'What is Hypertension?'):",
    value="What is ",
    key='prompt_input'
)

max_len = st.slider("Max length", min_value=20, max_value=200, value=50)
num_outputs = st.slider("Number of outputs", min_value=1, max_value=5, value=1)

output_placeholder = st.empty()

if st.button("Generate Explanation"):
    if not prompt.strip().lower().startswith("what is") or not prompt.strip().endswith("?"):
        st.error("Please enter the prompt in the form 'What is <disease_name>?'")
    else:
        with st.spinner("Generating..."):
            set_seed(42)
            input_ids = tokenizer(prompt, return_tensors="pt").input_ids

            outputs = model.generate(
                input_ids,
                max_length=max_len,
                num_return_sequences=num_outputs,
                do_sample=True,
                temperature=0.8,
                top_k=50,
                top_p=0.95,
                repetition_penalty=1.2,
                pad_token_id=tokenizer.eos_token_id,
                eos_token_id=tokenizer.eos_token_id
            )

            output_placeholder.empty()
            with output_placeholder.container():
                st.subheader("Generated Explanation")
                for i in range(num_outputs):
                    full_text = tokenizer.decode(outputs[i], skip_special_tokens=True)
                    prompt_text = tokenizer.decode(input_ids[0], skip_special_tokens=True)
                    # Remove prompt from generated text to show only explanation
                    clean_generated_text = full_text[len(prompt_text):].strip()
                    st.markdown(f"**Result {i+1}:** {clean_generated_text}")
